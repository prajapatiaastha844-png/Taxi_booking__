from contextlib import redirect_stdout
from io import StringIO
import re

from django.contrib.auth import get_user_model
from django.core import mail
from django.test import TestCase
from django.test import override_settings
from django.urls import reverse

from .models import Driver, User


class UserModelTests(TestCase):
    def test_create_user_hashes_password(self):
        user = User.objects.create_user(
            name="Prachi",
            email="prachi@example.com",
            mobile="9876543210",
            password="A-safe-customer-password-914!",
        )

        self.assertEqual(user.name, "Prachi")
        self.assertEqual(user.email, "prachi@example.com")
        self.assertEqual(user.mobile, "9876543210")
        self.assertNotEqual(user.password, "A-safe-customer-password-914!")
        self.assertTrue(user.check_password("A-safe-customer-password-914!"))
        self.assertFalse(user.check_password("wrong-password"))

    def test_driver_stores_profile_and_hashed_password(self):
        driver = Driver(
            name="Taylor Morgan",
            email="taylor@example.com",
            license_number="DL-123456",
            mobile="555-0198",
        )
        driver.set_password("A-safe-driver-password-914!")
        driver.save()

        self.assertEqual(driver.name, "Taylor Morgan")
        self.assertEqual(driver.email, "taylor@example.com")
        self.assertEqual(driver.license_number, "DL-123456")
        self.assertEqual(driver.mobile, "555-0198")
        self.assertNotEqual(driver.password, "A-safe-driver-password-914!")
        self.assertTrue(driver.check_password("A-safe-driver-password-914!"))
        self.assertFalse(driver.check_password("wrong-password"))
        self.assertEqual(str(driver), "Taylor Morgan")


class CustomerRegistrationTests(TestCase):
    def test_registration_page_displays_customer_fields(self):
        response = self.client.get(reverse("user_register"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'name="name"')
        self.assertContains(response, 'name="email"')
        self.assertContains(response, 'name="password"')
        self.assertContains(response, 'name="mobile"')

    def test_customer_can_register_with_hashed_password(self):
        response = self.client.post(
            reverse("user_register"),
            {
                "name": "Taylor Morgan",
                "email": "taylor@example.com",
                "password": "Safe-customer-password-914!",
                "mobile": "555-0198",
            },
        )

        self.assertRedirects(response, reverse("user_register"))
        customer = User.objects.get(email="taylor@example.com")
        self.assertEqual(customer.name, "Taylor Morgan")
        self.assertEqual(customer.mobile, "555-0198")
        self.assertNotEqual(customer.password, "Safe-customer-password-914!")
        self.assertTrue(customer.check_password("Safe-customer-password-914!"))

    def test_registration_rejects_duplicate_email_and_weak_password(self):
        User.objects.create_user(
            name="Existing customer",
            email="existing@example.com",
            mobile="555-0100",
            password="Existing-safe-password-914!",
        )

        response = self.client.post(
            reverse("user_register"),
            {
                "name": "Another customer",
                "email": "existing@example.com",
                "password": "123",
                "mobile": "555-0101",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(User.objects.count(), 1)
        self.assertContains(response, "already exists")
        self.assertContains(response, "too short")

    def test_registration_rejects_invalid_email_phone_and_blank_name(self):
        response = self.client.post(
            reverse("user_register"),
            {
                "name": "   ",
                "email": "not-an-email",
                "password": "Safe-customer-password-914!",
                "mobile": "phone-number",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(User.objects.count(), 0)
        self.assertContains(response, "Enter a valid email address")
        self.assertContains(response, "This field is required.")
        self.assertContains(response, "valid phone number")

    def test_registration_rejects_case_insensitive_duplicate_email(self):
        User.objects.create_user(
            name="Existing customer",
            email="existing@example.com",
            mobile="555-0100",
            password="Existing-safe-password-914!",
        )

        response = self.client.post(
            reverse("user_register"),
            {
                "name": "Another customer",
                "email": "EXISTING@example.com",
                "password": "Safe-customer-password-914!",
                "mobile": "555-0101",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(User.objects.count(), 1)
        self.assertContains(response, "A user with this email already exists")


class AdminLoginPageTests(TestCase):
    def test_home_page_is_public_and_links_to_admin_sign_in(self):
        response = self.client.get(reverse("home"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "City rides, in motion.")
        self.assertContains(response, reverse("admin:login"))
        self.assertContains(response, reverse("user_register"))

    def test_admin_login_page_is_custom_and_has_no_registration(self):
        response = self.client.get(reverse("admin:login"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "City rides, in motion.")
        self.assertContains(response, "Sign in to dashboard")
        self.assertContains(response, reverse("home"))
        self.assertContains(response, "Forgot your password?")
        self.assertNotContains(response, "Register")

    def test_admin_login_without_next_redirects_to_dashboard(self):
        get_user_model().objects.create_user(
            username="dispatcher",
            password="safe-test-password",
            is_staff=True,
        )

        response = self.client.post(
            reverse("admin:login"),
            {
                "username": "dispatcher",
                "password": "safe-test-password",
            },
        )

        self.assertRedirects(response, reverse("admin:index"))
        dashboard_response = self.client.get(reverse("admin:index"))
        self.assertEqual(dashboard_response.status_code, 200)

    def test_staff_user_can_sign_in(self):
        user_model = get_user_model()
        user_model.objects.create_user(
            username="dispatcher",
            password="safe-test-password",
            is_staff=True,
        )

        response = self.client.post(
            reverse("admin:login"),
            {
                "username": "dispatcher",
                "password": "safe-test-password",
                "next": reverse("admin:index"),
            },
            follow=True,
        )

        self.assertRedirects(response, reverse("admin:index"))
        self.assertTrue(self.client.session.get("_auth_user_id"))
        self.assertContains(response, "Your workspace for managing the people")
        self.assertContains(response, 'aria-label="Dashboard navigation"')
        self.assertContains(response, "Drivers")
        self.assertContains(response, f'href="{reverse("admin_drivers")}"')
        self.assertContains(response, "Users")
        self.assertContains(response, f'href="{reverse("admin_users")}"')
        self.assertContains(response, "Bookings")
        self.assertContains(response, "Logout")
        navbar = response.content.decode().split(
            '<nav class="dashboard-navbar"',
            maxsplit=1,
        )[1].split("</nav>", maxsplit=1)[0]
        self.assertIn(f'href="{reverse("admin_drivers")}"', navbar)
        self.assertIn(f'href="{reverse("admin_users")}"', navbar)

    def test_dashboard_requires_staff_access(self):
        user = get_user_model().objects.create_user(
            username="rider",
            password="safe-test-password",
        )
        self.client.force_login(user)

        response = self.client.get(reverse("admin:index"))

        self.assertRedirects(
            response,
            f"{reverse('admin:login')}?next={reverse('admin:index')}",
        )

    def test_non_staff_user_cannot_sign_in_to_admin(self):
        user_model = get_user_model()
        user_model.objects.create_user(
            username="rider",
            password="safe-test-password",
        )

        response = self.client.post(
            reverse("admin:login"),
            {
                "username": "rider",
                "password": "safe-test-password",
                "next": reverse("admin:index"),
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertFalse(self.client.session.get("_auth_user_id"))
        self.assertContains(response, "Please enter the correct")

    def test_staff_user_can_sign_out(self):
        user = get_user_model().objects.create_user(
            username="dispatcher",
            password="safe-test-password",
            is_staff=True,
        )
        self.client.force_login(user)

        response = self.client.post(reverse("admin:logout"), follow=True)

        self.assertRedirects(response, reverse("home"))
        self.assertNotIn("_auth_user_id", self.client.session)
        self.assertContains(response, "Admin sign in")


class AdminRegistrationTests(TestCase):
    def setUp(self):
        self.superuser = get_user_model().objects.create_superuser(
            username="owner",
            email="owner@example.com",
            password="safe-test-password",
        )

    def test_registration_page_requires_superuser(self):
        response = self.client.get(reverse("admin_register"))

        self.assertRedirects(
            response,
            f"{reverse('admin:login')}?next={reverse('admin_register')}",
            fetch_redirect_response=False,
        )

    def test_registration_page_rejects_regular_staff_users(self):
        staff_user = get_user_model().objects.create_user(
            username="manager",
            email="manager@example.com",
            password="safe-test-password",
            is_staff=True,
        )
        self.client.force_login(staff_user)

        response = self.client.get(reverse("admin_register"))

        self.assertRedirects(
            response,
            f"{reverse('admin:login')}?next={reverse('admin_register')}",
            fetch_redirect_response=False,
        )

    def test_superuser_can_register_admin_in_custom_table(self):
        self.client.force_login(self.superuser)

        registration_url = reverse("admin_register")
        page = self.client.get(registration_url)
        self.assertContains(page, 'name="phone"')

        response = self.client.post(
            registration_url,
            {
                "username": "dispatcher",
                "email": "dispatcher@example.com",
                "phone": "555-0198",
                "password1": "A-safe-test-password-137!",
                "password2": "A-safe-test-password-137!",
            },
        )

        self.assertRedirects(response, reverse("admin:index"))
        admin_user = get_user_model().objects.get(username="dispatcher")
        self.assertEqual(admin_user._meta.db_table, "core_admin")
        self.assertEqual(admin_user.phone, "555-0198")
        self.assertTrue(admin_user.is_staff)
        self.assertFalse(admin_user.is_superuser)
        self.assertTrue(admin_user.check_password("A-safe-test-password-137!"))


class AdminUserManagementTests(TestCase):
    def setUp(self):
        self.superuser = get_user_model().objects.create_superuser(
            username="owner",
            email="owner@example.com",
            password="safe-test-password",
        )
        self.customer = User.objects.create_user(
            name="Sam Rivera",
            email="sam@example.com",
            mobile="555-0123",
            password="customer-password",
        )

    def test_staff_user_can_manage_customer_users(self):
        staff_user = get_user_model().objects.create_user(
            username="manager",
            email="manager@example.com",
            password="safe-test-password",
            is_staff=True,
        )
        self.client.force_login(staff_user)

        response = self.client.get(reverse("admin_users"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Sam Rivera")

    def test_user_list_requires_staff_access(self):
        regular_user = get_user_model().objects.create_user(
            username="rider",
            email="rider@example.com",
            password="safe-test-password",
        )
        self.client.force_login(regular_user)

        response = self.client.get(reverse("admin_users"))

        self.assertRedirects(
            response,
            f"{reverse('admin:login')}?next={reverse('admin_users')}",
            fetch_redirect_response=False,
        )

    def test_superuser_can_view_and_search_users(self):
        self.client.force_login(self.superuser)

        response = self.client.get(reverse("admin_users"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Sam Rivera")
        self.assertContains(response, "sam@example.com")
        self.assertContains(response, "table table-striped table-hover align-middle")
        self.assertContains(
            response,
            "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css",
        )
        self.assertContains(response, reverse("admin_user_detail", args=[self.customer.pk]))
        self.assertContains(response, reverse("admin_user_edit", args=[self.customer.pk]))
        self.assertContains(response, reverse("admin_user_delete", args=[self.customer.pk]))

        search_response = self.client.get(reverse("admin_users"), {"q": "555-0123"})
        self.assertContains(search_response, "Sam Rivera")
        self.assertContains(search_response, "1 matching user")

        empty_response = self.client.get(reverse("admin_users"), {"q": "not-found"})
        self.assertContains(empty_response, "No matching users")

    def test_user_search_matches_name_and_email(self):
        User.objects.create_user(
            name="Avery Chen",
            email="avery@example.com",
            mobile="555-0456",
            password="A-safe-customer-password-914!",
        )
        self.client.force_login(self.superuser)

        name_response = self.client.get(reverse("admin_users"), {"q": "RIVERA"})
        self.assertContains(name_response, "Sam Rivera")
        self.assertContains(name_response, "1 matching user")
        self.assertNotContains(name_response, "Avery Chen")

        email_response = self.client.get(
            reverse("admin_users"),
            {"q": "SAM@EXAMPLE"},
        )
        self.assertContains(email_response, "Sam Rivera")
        self.assertContains(email_response, "1 matching user")
        self.assertNotContains(email_response, "Avery Chen")

    def test_staff_user_can_view_user_profile_without_exposing_password(self):
        self.client.force_login(self.superuser)

        response = self.client.get(
            reverse("admin_user_detail", args=[self.customer.pk])
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Sam Rivera")
        self.assertContains(response, "sam@example.com")
        self.assertContains(response, "555-0123")
        self.assertContains(response, f"#{self.customer.pk}")
        self.assertContains(
            response,
            reverse("admin_user_edit", args=[self.customer.pk]),
        )
        self.assertNotContains(response, self.customer.password)

    def test_user_profile_requires_staff_access(self):
        regular_user = get_user_model().objects.create_user(
            username="rider",
            email="rider@example.com",
            password="safe-test-password",
        )
        self.client.force_login(regular_user)

        response = self.client.get(
            reverse("admin_user_detail", args=[self.customer.pk])
        )

        self.assertRedirects(
            response,
            f"{reverse('admin:login')}?next={reverse('admin_user_detail', args=[self.customer.pk])}",
            fetch_redirect_response=False,
        )

    def test_user_profile_returns_not_found_for_unknown_user(self):
        self.client.force_login(self.superuser)

        response = self.client.get(
            reverse("admin_user_detail", args=[self.customer.pk + 999])
        )

        self.assertEqual(response.status_code, 404)

    def test_superuser_can_edit_user_without_changing_password(self):
        self.client.force_login(self.superuser)
        edit_url = reverse("admin_user_edit", args=[self.customer.pk])

        response = self.client.post(
            edit_url,
            {
                "name": "Sam Rivera",
                "email": "sam.updated@example.com",
                "mobile": "555-0199",
            },
        )

        self.assertRedirects(response, reverse("admin_users"))
        self.customer.refresh_from_db()
        self.assertEqual(self.customer.email, "sam.updated@example.com")
        self.assertEqual(self.customer.mobile, "555-0199")
        self.assertTrue(self.customer.check_password("customer-password"))

    def test_duplicate_email_is_rejected_when_editing_user(self):
        User.objects.create_user(
            name="Another Rider",
            email="another@example.com",
            mobile="555-0100",
            password="customer-password",
        )
        self.client.force_login(self.superuser)

        response = self.client.post(
            reverse("admin_user_edit", args=[self.customer.pk]),
            {
                "name": "Sam Rivera",
                "email": "another@example.com",
                "mobile": "555-0123",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "already exists")
        self.customer.refresh_from_db()
        self.assertEqual(self.customer.email, "sam@example.com")

    def test_user_delete_requires_confirmation_and_post(self):
        self.client.force_login(self.superuser)
        delete_url = reverse("admin_user_delete", args=[self.customer.pk])

        confirmation_response = self.client.get(delete_url)
        self.assertEqual(confirmation_response.status_code, 200)
        self.assertContains(confirmation_response, "This action cannot be undone.")
        self.assertTrue(User.objects.filter(pk=self.customer.pk).exists())

        delete_response = self.client.post(delete_url)
        self.assertRedirects(delete_response, reverse("admin_users"))
        self.assertFalse(User.objects.filter(pk=self.customer.pk).exists())


class AdminDriverManagementTests(TestCase):
    def setUp(self):
        self.superuser = get_user_model().objects.create_superuser(
            username="owner",
            email="owner@example.com",
            password="safe-test-password",
        )
        self.driver = Driver.objects.create(
            name="Taylor Morgan",
            email="taylor@example.com",
            license_number="DL-123456",
            mobile="555-0198",
            password="hashed-password",
        )

    def test_staff_can_view_and_search_driver_directory(self):
        self.client.force_login(self.superuser)

        response = self.client.get(reverse("admin_drivers"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Taylor Morgan")
        self.assertContains(response, "taylor@example.com")
        self.assertContains(response, "555-0198")
        self.assertContains(response, "DL-123456")
        self.assertContains(response, "<strong>1</strong>")
        self.assertContains(response, "total drivers")
        self.assertContains(
            response,
            reverse("admin_driver_detail", args=[self.driver.pk]),
        )

        search_response = self.client.get(
            reverse("admin_drivers"),
            {"q": "DL-123456"},
        )
        self.assertContains(search_response, "Taylor Morgan")
        self.assertContains(search_response, "1 matching driver")

        empty_response = self.client.get(
            reverse("admin_drivers"),
            {"q": "not-found"},
        )
        self.assertContains(empty_response, "No matching drivers")

    def test_driver_search_matches_all_directory_fields(self):
        Driver.objects.create(
            name="Jordan Lee",
            email="jordan@example.com",
            license_number="DL-789012",
            mobile="555-0111",
            password="hashed-password",
        )
        self.client.force_login(self.superuser)

        for query in ("Taylor", "taylor@example.com", "555-0198", "DL-123456"):
            with self.subTest(query=query):
                response = self.client.get(reverse("admin_drivers"), {"q": query})
                self.assertContains(response, "Taylor Morgan")
                self.assertNotContains(response, "Jordan Lee")

    def test_driver_directory_requires_staff_access(self):
        regular_user = get_user_model().objects.create_user(
            username="rider",
            email="rider@example.com",
            password="safe-test-password",
        )
        self.client.force_login(regular_user)

        response = self.client.get(reverse("admin_drivers"))

        self.assertRedirects(
            response,
            f"{reverse('admin:login')}?next={reverse('admin_drivers')}",
            fetch_redirect_response=False,
        )

    def test_staff_can_view_driver_profile_and_empty_booking_history(self):
        self.client.force_login(self.superuser)

        response = self.client.get(
            reverse("admin_driver_detail", args=[self.driver.pk])
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Taylor Morgan")
        self.assertContains(response, "taylor@example.com")
        self.assertContains(response, "555-0198")
        self.assertContains(response, "DL-123456")
        self.assertContains(response, "Booking history")
        self.assertContains(response, "No booking history yet")
        self.assertNotContains(response, self.driver.password)

    def test_driver_profile_requires_staff_access_and_returns_not_found(self):
        regular_user = get_user_model().objects.create_user(
            username="rider",
            email="rider@example.com",
            password="safe-test-password",
        )
        self.client.force_login(regular_user)

        response = self.client.get(
            reverse("admin_driver_detail", args=[self.driver.pk])
        )
        self.assertRedirects(
            response,
            f"{reverse('admin:login')}?next={reverse('admin_driver_detail', args=[self.driver.pk])}",
            fetch_redirect_response=False,
        )

        self.client.force_login(self.superuser)
        missing_response = self.client.get(
            reverse("admin_driver_detail", args=[self.driver.pk + 999])
        )
        self.assertEqual(missing_response.status_code, 404)

    def test_driver_delete_requires_confirmation_and_post(self):
        self.client.force_login(self.superuser)
        delete_url = reverse("admin_driver_delete", args=[self.driver.pk])

        confirmation_response = self.client.get(
            delete_url,
            {"q": "Taylor", "page": "2"},
        )
        self.assertEqual(confirmation_response.status_code, 200)
        self.assertContains(confirmation_response, "Taylor Morgan")
        self.assertContains(confirmation_response, "This action cannot be undone.")
        self.assertTrue(Driver.objects.filter(pk=self.driver.pk).exists())

        delete_response = self.client.post(
            delete_url,
            {"q": "Taylor", "page": "2"},
        )
        self.assertRedirects(
            delete_response,
            f"{reverse('admin_drivers')}?q=Taylor&page=2",
        )
        self.assertFalse(Driver.objects.filter(pk=self.driver.pk).exists())

    def test_driver_delete_requires_staff_and_unknown_id_is_not_found(self):
        regular_user = get_user_model().objects.create_user(
            username="rider",
            email="rider@example.com",
            password="safe-test-password",
        )
        self.client.force_login(regular_user)

        response = self.client.post(
            reverse("admin_driver_delete", args=[self.driver.pk])
        )
        self.assertRedirects(
            response,
            f"{reverse('admin:login')}?next={reverse('admin_driver_delete', args=[self.driver.pk])}",
            fetch_redirect_response=False,
        )
        self.assertTrue(Driver.objects.filter(pk=self.driver.pk).exists())

        self.client.force_login(self.superuser)
        missing_response = self.client.get(
            reverse("admin_driver_delete", args=[self.driver.pk + 999])
        )
        self.assertEqual(missing_response.status_code, 404)

    def test_driver_directory_paginates_full_driver_list(self):
        Driver.objects.bulk_create(
            [
                Driver(
                    name=f"Driver {number:02}",
                    email=f"driver{number}@example.com",
                    license_number=f"DL-{number:06}",
                    mobile=f"555-{number:04}",
                    password="hashed-password",
                )
                for number in range(11)
            ]
        )
        self.client.force_login(self.superuser)

        first_page = self.client.get(reverse("admin_drivers"))
        second_page = self.client.get(reverse("admin_drivers"), {"page": "2"})

        self.assertContains(first_page, "<strong>12</strong>")
        self.assertContains(first_page, "Page 1 of 2")
        self.assertContains(second_page, "Page 2 of 2")
        self.assertContains(second_page, "Taylor Morgan")


@override_settings(
    EMAIL_BACKEND="django.core.mail.backends.locmem.EmailBackend",
    DEFAULT_FROM_EMAIL="no-reply@example.com",
)
class AdminPasswordResetTests(TestCase):
    def setUp(self):
        self.admin_user = get_user_model().objects.create_user(
            username="dispatcher",
            email="dispatcher@example.com",
            password="safe-test-password",
            is_staff=True,
        )

    def test_reset_form_has_email_field(self):
        response = self.client.get(reverse("admin_password_reset"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'type="email"')
        self.assertContains(response, "Email address")

    def test_password_reset_requires_otp_before_setting_new_password(self):
        response = self.client.post(
            reverse("admin_password_reset"),
            {"email": self.admin_user.email},
        )

        self.assertRedirects(response, reverse("admin_password_reset_done"))
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("dispatcher@example.com", mail.outbox[0].to)
        otp_match = re.search(r"\b\d{6}\b", mail.outbox[0].body)
        self.assertIsNotNone(otp_match)
        otp = otp_match.group()

        verify_response = self.client.get(reverse("admin_password_reset_verify"))
        self.assertEqual(verify_response.status_code, 200)
        self.assertContains(verify_response, "Verify your code")

        new_password_response = self.client.post(
            reverse("admin_password_reset_verify"),
            {"otp": otp},
        )
        self.assertRedirects(
            new_password_response,
            reverse("admin_password_reset_new"),
        )
        self.assertContains(
            self.client.get(reverse("admin_password_reset_new")),
            "Your verification code is confirmed",
        )
        self.admin_user.refresh_from_db()
        self.assertTrue(self.admin_user.check_password("safe-test-password"))

        new_password = "An-even-safer-new-pass-947!"
        complete_response = self.client.post(
            reverse("admin_password_reset_new"),
            {
                "new_password1": new_password,
                "new_password2": new_password,
            },
        )

        self.assertRedirects(
            complete_response,
            reverse("admin_password_reset_complete"),
        )
        self.admin_user.refresh_from_db()
        self.assertTrue(self.admin_user.check_password(new_password))

    def test_cannot_set_password_before_otp_verification(self):
        response = self.client.get(reverse("admin_password_reset_new"))

        self.assertRedirects(response, reverse("admin_password_reset"))

    @override_settings(
        EMAIL_BACKEND="django.core.mail.backends.console.EmailBackend",
    )
    def test_password_reset_otp_is_printed_by_console_email_backend(self):
        output = StringIO()
        with redirect_stdout(output):
            response = self.client.post(
                reverse("admin_password_reset"),
                {"email": self.admin_user.email},
            )

        self.assertRedirects(response, reverse("admin_password_reset_done"))
        self.assertRegex(output.getvalue(), r"Your password reset verification code is \d{6}\.")

    def test_incorrect_otp_does_not_change_password(self):
        self.client.post(
            reverse("admin_password_reset"),
            {"email": self.admin_user.email},
        )
        otp = re.search(r"\b\d{6}\b", mail.outbox[0].body).group()
        incorrect_otp = f"{(int(otp) + 1) % 1_000_000:06d}"
        response = self.client.post(
            reverse("admin_password_reset_verify"),
            {
                "otp": incorrect_otp,
                "new_password1": "An-even-safer-new-pass-947!",
                "new_password2": "An-even-safer-new-pass-947!",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "verification code is incorrect")
        self.admin_user.refresh_from_db()
        self.assertTrue(self.admin_user.check_password("safe-test-password"))

    def test_unknown_email_gets_same_confirmation_without_sending_mail(self):
        response = self.client.post(
            reverse("admin_password_reset"),
            {"email": "unknown@example.com"},
        )

        self.assertRedirects(response, reverse("admin_password_reset_done"))
        self.assertEqual(len(mail.outbox), 0)
