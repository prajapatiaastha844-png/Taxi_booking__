import hashlib
import hmac
import random
import time
from urllib.parse import urlencode

from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import user_passes_test
from django.conf import settings
from django.core.paginator import Paginator
from django.core.mail import send_mail
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render, reverse
from django.template.loader import render_to_string
from django.utils.translation import gettext as _

from .forms import (
    AdminPasswordResetOTPForm,
    AdminPasswordResetRequestForm,
    AdminRegistrationForm,
    AdminSetNewPasswordForm,
    CustomerRegistrationForm,
    CustomerUserForm,
)
from .models import Driver, User

PASSWORD_RESET_SESSION_KEY = "admin_password_reset_otp"
PASSWORD_RESET_OTP_TTL = 10 * 60
PASSWORD_RESET_OTP_MAX_ATTEMPTS = 5


def generate_password_reset_otp():
    return f"{random.SystemRandom().randrange(1_000_000):06d}"


def home(request):
    return render(request, "home.html")


def _hash_password_reset_otp(otp):
    return hmac.new(
        settings.SECRET_KEY.encode("utf-8"),
        otp.encode("ascii"),
        hashlib.sha256,
    ).hexdigest()


def admin_password_reset(request):
    if request.method == "POST":
        form = AdminPasswordResetRequestForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data["email"]
            user_model = get_user_model()
            user = next(
                (
                    candidate
                    for candidate in user_model.objects.filter(
                        email__iexact=email,
                        is_active=True,
                        is_staff=True,
                    )
                    if candidate.has_usable_password()
                ),
                None,
            )

            if user is not None:
                otp = generate_password_reset_otp()
                request.session[PASSWORD_RESET_SESSION_KEY] = {
                    "user_id": user.pk,
                    "otp_hash": _hash_password_reset_otp(otp),
                    "expires_at": int(time.time()) + PASSWORD_RESET_OTP_TTL,
                    "attempts": 0,
                }
                send_mail(
                    render_to_string(
                        "admin/password_reset_subject.txt",
                    ).strip(),
                    render_to_string(
                        "admin/password_reset_email.txt",
                        {"otp": otp, "email": user.email},
                    ),
                    settings.DEFAULT_FROM_EMAIL,
                    [user.email],
                )

            return redirect("admin_password_reset_done")
    else:
        form = AdminPasswordResetRequestForm()

    return render(request, "admin/password_reset_form.html", {"form": form})


def admin_password_reset_verify(request):
    reset_data = request.session.get(PASSWORD_RESET_SESSION_KEY)
    if not isinstance(reset_data, dict):
        return render(
            request,
            "admin/password_reset_otp.html",
            {
                "form": AdminPasswordResetOTPForm(),
                "error": _("This code is invalid or has expired. Request a new code."),
            },
        )

    user_model = get_user_model()
    user = user_model.objects.filter(
        pk=reset_data.get("user_id"),
        is_active=True,
        is_staff=True,
    ).first()
    if user is None:
        request.session.pop(PASSWORD_RESET_SESSION_KEY, None)
        return render(
            request,
            "admin/password_reset_otp.html",
            {
                "form": AdminPasswordResetOTPForm(),
                "error": _("This code is invalid or has expired. Request a new code."),
            },
        )

    form = AdminPasswordResetOTPForm(request.POST if request.method == "POST" else None)
    error = None

    if time.time() >= reset_data.get("expires_at", 0):
        request.session.pop(PASSWORD_RESET_SESSION_KEY, None)
        error = _("This code is invalid or has expired. Request a new code.")
    elif reset_data.get("attempts", 0) >= PASSWORD_RESET_OTP_MAX_ATTEMPTS:
        request.session.pop(PASSWORD_RESET_SESSION_KEY, None)
        error = _("Too many attempts. Request a new code.")
    elif request.method == "POST":
        otp = request.POST.get("otp", "")
        submitted_hash = (
            _hash_password_reset_otp(otp)
            if len(otp) == 6 and otp.isascii() and otp.isdigit()
            else ""
        )
        if not hmac.compare_digest(
            submitted_hash,
            reset_data.get("otp_hash", ""),
        ):
            reset_data["attempts"] += 1
            request.session[PASSWORD_RESET_SESSION_KEY] = reset_data
            form.add_error("otp", _("The verification code is incorrect."))
        elif form.is_valid():
            reset_data["verified"] = True
            request.session[PASSWORD_RESET_SESSION_KEY] = reset_data
            return redirect("admin_password_reset_new")

    return render(
        request,
        "admin/password_reset_otp.html",
        {"form": form, "error": error},
    )


def admin_password_reset_new(request):
    reset_data = request.session.get(PASSWORD_RESET_SESSION_KEY)
    if (
        not isinstance(reset_data, dict)
        or not reset_data.get("verified")
        or time.time() >= reset_data.get("expires_at", 0)
    ):
        request.session.pop(PASSWORD_RESET_SESSION_KEY, None)
        return redirect("admin_password_reset")

    user = get_user_model().objects.filter(
        pk=reset_data.get("user_id"),
        is_active=True,
        is_staff=True,
    ).first()
    if user is None:
        request.session.pop(PASSWORD_RESET_SESSION_KEY, None)
        return redirect("admin_password_reset")

    form = AdminSetNewPasswordForm(
        request.POST if request.method == "POST" else None,
        user=user,
    )
    if request.method == "POST" and form.is_valid():
        user.set_password(form.cleaned_data["new_password1"])
        user.save(update_fields=["password"])
        request.session.pop(PASSWORD_RESET_SESSION_KEY, None)
        return redirect("admin_password_reset_complete")

    return render(
        request,
        "admin/password_reset_new.html",
        {"form": form},
    )


@user_passes_test(
    lambda user: user.is_active and user.is_superuser,
    login_url="admin:login",
)
def register_admin(request):
    if request.method == "POST":
        form = AdminRegistrationForm(request.POST)
        if form.is_valid():
            admin_user = form.save(commit=False)
            admin_user.is_staff = True
            admin_user.is_superuser = False
            admin_user.save()
            messages.success(request, "Admin account created successfully.")
            return redirect("admin:index")
    else:
        form = AdminRegistrationForm()

    return render(request, "admin/register.html", {"form": form})


def register_user(request):
    form = CustomerRegistrationForm(
        request.POST if request.method == "POST" else None,
    )
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, _("Your account has been created successfully."))
        return redirect("user_register")

    return render(request, "register.html", {"form": form})


@user_passes_test(
    lambda user: user.is_active and user.is_staff,
    login_url="admin:login",
)
def user_list(request):
    search_query = request.GET.get("q", "").strip()
    users = User.objects.all()
    if search_query:
        users = users.filter(
            Q(name__icontains=search_query)
            | Q(email__icontains=search_query)
            | Q(mobile__icontains=search_query)
        )

    paginator = Paginator(users.order_by("name", "pk"), 10)
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(
        request,
        "admin/user_list.html",
        {
            "page_obj": page_obj,
            "search_query": search_query,
            "total_users": User.objects.count(),
        },
    )


@user_passes_test(
    lambda user: user.is_active and user.is_staff,
    login_url="admin:login",
)
def driver_list(request):
    search_query = request.GET.get("q", "").strip()
    drivers = Driver.objects.all()
    if search_query:
        drivers = drivers.filter(
            Q(name__icontains=search_query)
            | Q(email__icontains=search_query)
            | Q(mobile__icontains=search_query)
            | Q(license_number__icontains=search_query)
        )

    paginator = Paginator(drivers.order_by("name", "pk"), 10)
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(
        request,
        "admin/driver_list.html",
        {
            "page_obj": page_obj,
            "search_query": search_query,
            "total_drivers": Driver.objects.count(),
        },
    )


@user_passes_test(
    lambda user: user.is_active and user.is_staff,
    login_url="admin:login",
)
def driver_detail(request, driver_id):
    driver = get_object_or_404(Driver, pk=driver_id)
    return render(
        request,
        "admin/driver_detail.html",
        {"driver": driver},
    )


@user_passes_test(
    lambda user: user.is_active and user.is_staff,
    login_url="admin:login",
)
def driver_delete(request, driver_id):
    driver = get_object_or_404(Driver, pk=driver_id)
    search_query = request.GET.get("q", "").strip()
    page = request.GET.get("page", "1")
    if request.method == "POST":
        search_query = request.POST.get("q", "").strip()
        page = request.POST.get("page", "1")
        driver_name = driver.name
        driver.delete()
        messages.success(request, f"{driver_name} was deleted.")
        query = urlencode({"q": search_query, "page": page})
        return redirect(f"{reverse('admin_drivers')}?{query}")

    return render(
        request,
        "admin/driver_delete.html",
        {
            "driver": driver,
            "search_query": search_query,
            "page": page,
        },
    )


@user_passes_test(
    lambda user: user.is_active and user.is_staff,
    login_url="admin:login",
)
def user_detail(request, user_id):
    customer = get_object_or_404(User, pk=user_id)
    return render(
        request,
        "admin/user_detail.html",
        {"customer": customer},
    )


@user_passes_test(
    lambda user: user.is_active and user.is_staff,
    login_url="admin:login",
)
def user_edit(request, user_id):
    customer = get_object_or_404(User, pk=user_id)
    form = CustomerUserForm(
        request.POST if request.method == "POST" else None,
        instance=customer,
    )
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, f"{customer.name} updated successfully.")
        return redirect("admin_users")

    return render(
        request,
        "admin/user_edit.html",
        {"form": form, "customer": customer},
    )


@user_passes_test(
    lambda user: user.is_active and user.is_staff,
    login_url="admin:login",
)
def user_delete(request, user_id):
    customer = get_object_or_404(User, pk=user_id)
    if request.method == "POST":
        customer_name = customer.name
        customer.delete()
        messages.success(request, f"{customer_name} was deleted.")
        return redirect("admin_users")

    return render(
        request,
        "admin/user_delete.html",
        {"customer": customer},
    )
